import React from 'react';
import './index.css'
import './App.js'

function App() {
  return (
    <div>
    <div className="container mx-auto p-4 pt-6 md:p-6 lg:p-12 flex !important">
      <h1 className="text-3xl font-bold underline">Hello World!</h1>
      <h2 className="text-3xl font-bold underline">Hello World!</h2>
      </div>

      <div className='flex border p-4'>
       <a className='p-4' href='/'>Home</a>
       <a href='/movies'>Movies</a>
      </div>
    </div>
  );
}
export default App