import React from 'react'

function Navbar() {
  return (
    <div>



<h1 className="text-3xl font-bold text-underline">Hello World!</h1>
<h2>shruti</h2>
    </div>
  )
}

export default Navbar